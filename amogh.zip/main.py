name = input('What is your name?')
print('Hi, %s.' % name)
input('press enter to end')